********************************************************************
	SPYKA WEBMASTER - HTTP://WWW.SPYKA.NET
	FREE WEB TEMPLATES AND RESOURCES FOR WEBMASTERS
********************************************************************

This is a free script by spyka webmaster (http://www.spyka.net)

1. Installation
-----------------------------------------
Please find full documentation for this script here: http://www.spyka.net/docs/short-url-script


2. Licence
-----------------------------------------
This script is licensed under a Creative Commons Attribution 3.0 licence. This allows you to use, modify and distribute the script permitted the link to spyka.net REMAINS.

If you wish to remove this link you can buy a script licence for �4.00 - http://www.spyka.net/licence for more information


2. Help and support
-----------------------------------------
You can get help and support for this script plus other web design and development tips from our webmaster forums: http://community.spyka.co.uk/forumdisplay.php?f=9


3. Other information
-----------------------------------------
Please contact us if you need more information about this script - spyka.net/contact
